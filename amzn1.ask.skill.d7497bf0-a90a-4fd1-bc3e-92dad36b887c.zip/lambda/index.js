/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const word_1 = "sky";
const word_2 = "boy";
const word_3 = "bee";
//const vector = [word_1, word_2, word_3];


const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    async handle(handlerInput) {
        
        const {attributesManager, requestEnvelope} = handlerInput;
        const sessionAttributes = await attributesManager.getSessionAttributes()|| {};
        const vector_word_1 = ["S", "K.", "Y"];
        sessionAttributes.vector_word_1 = vector_word_1;
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        
        let speakOutput2 = "I will say a word! Try to spell this word: " + word_1;
        
        return handlerInput.responseBuilder
                .speak(speakOutput2)
                .reprompt(speakOutput2)
                .getResponse();
    
    }
};
        
const LanguageIntentHandler = {
    canHandle(handlerInput) {
        
        const attributes = handlerInput.attributesManager.getSessionAttributes();
        const request = handlerInput.requestEnvelope.request; 
        
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LanguageIntent';
    },
    async handle(handlerInput) {
        
        const {attributesManager, requestEnvelope} = handlerInput;
        const sessionAttributes = await attributesManager.getSessionAttributes()|| {};
        const {intent} = requestEnvelope.request;
        const check_vector_1 = sessionAttributes.vector_word_1;
    
        const letter_1 = Alexa.getSlotValue(requestEnvelope, 'letter_a');
        console.log(letter_1);
        const letter_2 = Alexa.getSlotValue(requestEnvelope, 'letter_b');
        console.log(letter_2);
        const letter_3 = Alexa.getSlotValue(requestEnvelope, 'letter_c');
        console.log(letter_3);
        
        let user_word = [letter_1, letter_2, letter_3];
        console.log(user_word);
        let score = 0; 
        
        for (let user_letter of user_word) {
            for (let letter of check_vector_1) {
              if (user_letter === letter) {
                  score = score + 1; 
                  console.log(score);
              }
            }
        }
           let speakOutput1 = "Your score is: " + score;
           
           let speakOutput2 = "I will say another word! Try to spell it: " + word_2;
           
           const vector_word_2 = ["B", "O", "Y"];
           const check_vector_2 = vector_word_2;
           const letter_4 = Alexa.getSlotValue(requestEnvelope, 'letter_a');
           console.log(letter_4);
           const letter_5 = Alexa.getSlotValue(requestEnvelope, 'letter_b');
           console.log(letter_5);
           const letter_6 = Alexa.getSlotValue(requestEnvelope, 'letter_c');
           console.log(letter_6);
    
           let user_word_1 = [letter_4, letter_5, letter_6];
        console.log(user_word_1);
        
        for (let user_letter_1 of user_word_1) {
            for (let letter_1 of check_vector_2) {
              if (user_letter_1 === letter_1) {
                  score = score + 1; 
                  console.log(score);
              }
            }
        }
           let speakOutput3 = "Your score is: " + score;
           
           
           
        
              return handlerInput.responseBuilder
                .speak(speakOutput1+speakOutput2)
                .reprompt(speakOutput1+speakOutput2)
                .getResponse();
    }
};


const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        LanguageIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();